﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h),_(c,i,e,f,g,j),_(c,k,e,f,g,l)]);}; 
var b="rootNodes",c="pageName",d="主页",e="type",f="Wireframe",g="url",h="主页.html",i="书籍详情页",j="书籍详情页.html",k="新增书籍表单",l="新增书籍表单.html";
return _creator();
})();
